package com.example.chatbot.utils

object Constants {
    const val SEND_ID="SEND_ID"
    const val RECIEVE_ID="RECIEVE_ID"

    const val OPEN_GOOGLE="Opening Google..."
    const val OPEN_SEARCH="Searching..."
}