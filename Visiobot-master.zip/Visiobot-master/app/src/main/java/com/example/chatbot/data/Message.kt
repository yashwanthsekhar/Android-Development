package com.example.chatbot.data

data class Message(val message:String,val id:String ,val time:String) {

}